package in.rikcapital.stockalert.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import in.rikcapital.stockalert.model.StockAlertRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Sends Stock Alert notifications through the Resend HTTP API.
 * No SMTP / JavaMail dependency is used.
 */
@Service
public class StockAlertEmailService {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final String apiUrl;
    private final String apiKey;
    private final String adminEmail;
    private final String fromEmail;

    public StockAlertEmailService(
            ObjectMapper objectMapper,
            @Value("${stock-alert.email-api-url:https://api.resend.com/emails}") String apiUrl,
            @Value("${RESEND_API_KEY:}") String apiKey,
            @Value("${stock-alert.admin-email:admin@rikcapital.in}") String adminEmail,
            @Value("${stock-alert.from-email:RIK Capital <alerts@rikcapital.in>}") String fromEmail) {
        this.httpClient = HttpClient.newBuilder().build();
        this.objectMapper = objectMapper;
        this.apiUrl = apiUrl;
        this.apiKey = apiKey;
        this.adminEmail = adminEmail;
        this.fromEmail = fromEmail;
    }

    public void send(StockAlertRequest request) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("RESEND_API_KEY is not configured.");
        }

        try {
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("from", fromEmail);

            ArrayNode to = payload.putArray("to");
            to.add(adminEmail);

            payload.put("subject", "Stock Alert Request – RIK Capital");
            payload.put("reply_to", request.email());
            payload.put("text", buildBody(request));

            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(payload)))
                    .build();

            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException("Email API rejected the request: HTTP "
                        + response.statusCode() + " - " + response.body());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Email API request was interrupted.", e);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to send Stock Alert email through the email API.", e);
        }
    }

    private String buildBody(StockAlertRequest r) {
        return "Dear Admin,\n\n"
                + "A new Stock Alert request has been submitted through the RIK Capital website.\n\n"
                + "User Details\n\n"
                + "Name: " + r.name() + "\n"
                + "Email ID: " + r.email() + "\n"
                + "Phone Number: " + r.phone() + "\n\n"
                + "Selected Companies\n\n"
                + numberedCompanies(r) + "\n"
                + "Please review the request and take the necessary action.\n\n"
                + "Regards,\n"
                + "RIK Capital\n"
                + "Strategic Investor Relations Advisory\n";
    }

    private String numberedCompanies(StockAlertRequest r) {
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < r.companies().size(); i++) {
            body.append(i + 1).append(". ").append(r.companies().get(i)).append("\n");
        }
        return body.toString();
    }
}
